#### Instrucciones:

En el folder /img, van a encontrar la imagen con nombre "landing-page-DrupalCamp2014.png". La asignacion consiste en transladar a HTML/CSS el diseño de la imagen. En el mismo folder, van a encontrar todas las imagenes necesarias. 

Requerimientos:

* El layout debe ser flexible (usar %)
* El header, hero image y footer 100% width
* El area de contenido tiene un ancho maximo de 1000px.
* La navegacion (barra negra en header) es fixed.
* Markup, usar elemento de HTML5
 